# -*- coding: utf-8 -*-

authenticate = {'username':'918b4cfe-9cc9-4586-ac6f-928ee81e2444',
                'password':'mORsDpKiPiWG',
                'version':'2018-03-16'}